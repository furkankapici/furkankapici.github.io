<?php
include('veritabani_baglanti.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Kullanıcıyı veritabanından al
    $sql = "SELECT id, kullaniciadi, sifre FROM kullanicilar WHERE kullaniciadi = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
        if (password_verify($password, $row['sifre'])) {
            session_start();
            $_SESSION['user_id'] = $row['id'];
            $_SESSION['username'] = $row['kullaniciadi'];
            header("location: anasayfa.php"); // Giriş başarılıysa ana sayfaya yönlendir
        } else {
            echo "Hatalı şifre.";
        }
    } else {
        echo "Kullanıcı bulunamadı.";
    }

    $stmt->close();
}

$conn->close();
?>
