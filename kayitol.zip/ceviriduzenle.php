<?php
session_start(); // Oturumu başlat

// Oturum kontrolü yap
if (!isset($_SESSION['username'])) {
    header("location: girisyap.php"); // Kullanıcı giriş yapmamışsa giriş sayfasına yönlendir
    exit(); // Kodun devamını çalıştırma
}

include('veritabani_baglanti.php'); // Veritabanı bağlantısı

// Kullanıcının ID'sini alın (örneğin, GET isteği ile alabilirsiniz)
if (isset($_SESSION['user_id'])) {
    $kullanici_id = $_SESSION['user_id']; // Oturum bilgilerinden kullanıcı kimliğini alın

    // Veriyi düzenleme formu gönderildiyse
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Formdan gelen metin verisini alın
        $yeni_metin = $_POST['yeni_metin'];

        // Metin güncelleme SQL sorgusu
        $stmt = $conn->prepare("UPDATE metinler SET metin = ? WHERE kullanici_id = ?");
        $stmt->bind_param("si", $yeni_metin, $kullanici_id);

        if ($stmt->execute()) {
            header("Location: calismam.php");
        } else {
            echo "Metin güncelleme başarısız: " . $conn->error;
        }
    }

    // Kullanıcının mevcut metnini çekme SQL sorgusu
    $stmt = $conn->prepare("SELECT metin FROM metinler WHERE kullanici_id = ?");
    $stmt->bind_param("i", $kullanici_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $mevcut_metin = $row["metin"];
    } else {
        $mevcut_metin = "Kullanıcının metni bulunmuyor.";
    }
} else {
    echo "Kullanıcı ID'si eksik.";
}

// Veritabanı bağlantısını kapatın
$conn->close();
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Çevirinizi Düzenleyin</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #fff;
            margin: 0;
            padding: 0;
            display: flex;
        }

        a {
            display: block;
            text-align: center;
            text-decoration: none;
            background-color: #007bff;
            color: #fff;
            padding: 10px;
            border-radius: 3px;
        }

        a:hover {
            background-color: #0056b3;
        }
		
		.kaydet {
			position: absolute;
			bottom: 2%;
			left: 1%;
		}
    </style>
</head>
<body>
<h1>Metninizi Güncelleyin:</h1><br><br>
    <form method="POST" action="">
        <textarea name="yeni_metin" style="position: absolute; width: 97%; top: 10%; left: 1%; height: 83%;"><?php echo $mevcut_metin; ?></textarea><br>
        <input class="kaydet" type="submit" value="Metni Güncelle">
    </form>
</body>
</html>
