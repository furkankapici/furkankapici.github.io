<?php
session_start(); // Oturumu başlat

// Oturum kontrolü yap
if (!isset($_SESSION['username'])) {
    header("location: girisyap.php"); // Kullanıcı giriş yapmamışsa giriş sayfasına yönlendir
    exit(); // Kodun devamını çalıştırma
}

?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Diğerlerinin çevirileri</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #fff;
            margin: 0;
            padding: 0;
            display: flex;
        }

        a {
            display: block;
            text-align: center;
            text-decoration: none;
            background-color: #007bff;
            color: #fff;
            padding: 10px;
            border-radius: 3px;
        }

        a:hover {
            background-color: #0056b3;
        }
		
		.icerik {
			position: absolute;
			right: 0px;
			top: 0px;
			height: 100%;
			width: 81%;
		}
    </style>
</head>
<body>
<div class="icerik">
<?php
include('veritabani_baglanti.php');

$sql = "SELECT metinler.metin, kullanicilar.kullaniciadi
        FROM metinler, kullanicilar
        WHERE metinler.kullanici_id = kullanicilar.id";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<div>Kullanıcı Adı: " . $row["kullaniciadi"] . "<br>Metin:<br><textarea readonly style=' width: 98%' rows='16'>" . $row["metin"] . "</textarea></div>";
    }
} else {
    echo "Metin bulunamadı.";
}

$conn->close();
?>

</div>
<?php include('yanmenu.php'); ?>

</body>
</html>
