<?php
session_start(); // Oturumu başlat

// Oturum kontrolü yap
if (!isset($_SESSION['username'])) {
    header("location: girisyap.php"); // Kullanıcı giriş yapmamışsa giriş sayfasına yönlendir
    exit(); // Kodun devamını çalıştırma
}

?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hoş Geldiniz, <?php echo $_SESSION['username']; ?></title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #fff;
            margin: 0;
            padding: 0;
            display: flex;
        }

        a {
            display: block;
            text-align: center;
            text-decoration: none;
            background-color: #007bff;
            color: #fff;
            padding: 10px;
            border-radius: 3px;
        }

        a:hover {
            background-color: #0056b3;
        }
		
		.icerik {
			position: absolute;
			right: 0px;
			top: 0px;
			height: 100%;
			width: 82%;
		}
    </style>
</head>
<body>
<div class="icerik">
<h1>Hoş Geldiniz, <?php echo $_SESSION['username']; ?></h1><br><br>
<h2>Çalışmanızın son durumu</h2>

</div>
<?php include('yanmenu.php'); ?>

</body>
</html>
