<style>
/* Yan Menü Stili */
.sidebar {
    background-color: #333;
    width: 18%;
    height: 100%;
    position: fixed;
    top: 0;
    left: 0;
    overflow-y: auto;
    padding-top: 20px;
    color: #fff;
}

.sidebar ul {
    list-style-type: none;
    padding: 0;
}

.sidebar ul li {
    margin-bottom: 10px;
}

.sidebar a {
    display: block;
    padding: 10px 20px;
    text-decoration: none;
    color: #fff;
    transition: background-color 0.3s;
}

.sidebar a:hover {
    background-color: #555;
}
</style>
<div class="sidebar">
    <ul>
        <li><a href="anasayfa.php">Anasayfa</a></li>
		<li><a href="calismam.php">Çalışmamın son hali</a></li>
		<li><a href="ceviridevam.php">Çeviriye devam et</a></li>
		<li><a href="butunceviriler.php">Diğerleri nasıl gidiyor?</a></li>
		<?php
        // Veritabanından odaları çek
        include('veritabani_baglanti.php'); // Veritabanı bağlantısı
        $sql = "SELECT * FROM odalar";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo '<li><a href="oda_mesajlari.php?oda_id=' . $row['oda_id'] . '">' . $row['oda_adi'] . '</a></li>';
            }
        } else {
            echo '<li>Henüz bir oda oluşturulmadı.</li>';
        }

        $conn->close();
        ?>
		<li><a href="cikis.php">Çıkış Yap</a></li>
    </ul>
	
</div>

