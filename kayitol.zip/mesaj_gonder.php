<?php
session_start(); // Oturumu başlat

// Kullanıcı oturumunu kontrol et
if (isset($_SESSION['user_id'])) {
    // Veritabanı bağlantısını içe aktarın
    include('veritabani_baglanti.php');

    // POST verilerini alın
    if (isset($_POST['oda_id']) && isset($_POST['mesaj_metni'])) {
        $oda_id = $_POST['oda_id'];
        $mesaj_metni = $_POST['mesaj_metni'];
        $kullanici_id = $_SESSION['user_id']; // Oturum bilgilerinden kullanıcı kimliğini alın

        // Mesajı veritabanına ekleyin
        $sql = "INSERT INTO mesajlar (oda, kullanici_id, mesaj_metni) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("iis", $oda_id, $kullanici_id, $mesaj_metni);

        if ($stmt->execute()) {
            echo "Mesaj başarıyla gönderildi.";
        } else {
            echo "Hata: " . $stmt->error;
        }

        $stmt->close();
    } else {
        echo "Geçersiz istek.";
    }

    // Veritabanı bağlantısını kapatın
    $conn->close();
} else {
    echo "Oturum açılmış bir kullanıcı bulunamadı. Lütfen oturum açın.";
}
?>
