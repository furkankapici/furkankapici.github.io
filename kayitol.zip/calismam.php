<?php
session_start(); // Oturumu başlat

// Oturum kontrolü yap
if (!isset($_SESSION['username'])) {
    header("location: girisyap.php"); // Kullanıcı giriş yapmamışsa giriş sayfasına yönlendir
    exit(); // Kodun devamını çalıştırma
}

?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Çalışmanızın son durumu</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #fff;
            margin: 0;
            padding: 0;
            display: flex;
        }

        a {
            display: block;
            text-align: center;
            text-decoration: none;
            background-color: #007bff;
            color: #fff;
            padding: 10px;
            border-radius: 3px;
        }

        a:hover {
            background-color: #0056b3;
        }
		
		.icerik {
			position: absolute;
			right: 0px;
			top: 0px;
			height: 100%;
			width: 82%;
		}
		
		.ceviridevam {
			position: absolute;
			left: 3%;
			bottom: 3%;
			height: 3%;
			width: 12%;
		}
		
		.duzenlebuton {
			position: absolute;
			left: 18%;
			bottom: 3%;
			height: 3%;
			width: 7%;
		}
		
		.klasikcevirimodubuton {
			position: absolute;
			left: 28%;
			bottom: 3%;
			height: 3%;
			width: 25%;
		}
		

    </style>
	</head>
<body>
<div class="icerik">
<h1>En son burada kalmıştınız:</h1>
<?php
include('veritabani_baglanti.php'); // Veritabanı bağlantısı

// Kullanıcının ID'sini alın (örneğin, GET isteği ile alabilirsiniz)
if (isset($_SESSION['user_id'])) {
    $kullanici_id = $_SESSION['user_id']; // Oturum bilgilerinden kullanıcı kimliğini alın

    // Metinleri çekmek için güvenli bir şekilde MySQL sorgusu oluşturun
    $stmt = $conn->prepare("SELECT metin FROM metinler WHERE kullanici_id = ?");
    $stmt->bind_param("i", $kullanici_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Sonuçları döngü ile alın ve ekrana yazdırın
        while ($row = $result->fetch_assoc()) {
            echo "<textarea readonly style='position: absolute; top: 10%; right: 2%; width: 96%; height: 77%;'>" . $row["metin"] . "</textarea>";
        }
    } else {
        echo "Bu kullanıcının metni bulunmuyor.";
    }
} else {
    echo "Kullanıcı ID'si eksik.";
}

// Veritabanı bağlantısını kapatın
$conn->close();
?>
<a class="ceviridevam" href="ceviridevam.php">Çeviriye devam et</a> <a class="duzenlebuton" href="ceviriduzenle.php">Düzenle</a> <a class="klasikcevirimodubuton" href="ceviri.php">Düzenleme aracını klasik modda başlat</a>
</div>

<?php include('yanmenu.php'); ?>

</body>
</html>