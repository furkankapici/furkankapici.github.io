<?php
session_start(); // Oturumu başlat

// Eğer kullanıcı zaten oturum açtıysa, anasayfaya yönlendir
if (isset($_SESSION['user_id'])) {
    header("Location: anasayfa.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hoş Geldiniz</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            background-color: #f7f7f7;
        }
        .container {
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Hoş Geldiniz</h1>
        <p>Bu websitesi Super Mario Galaxy oyunun çevirilmesi için Furkan09 tarafından hazırlanmıştır</p>
        <div>
		Çeviri ekibine katılmak için çeviri kingdoma gelebilir ya da Discord üzerinden benimle iletişim kurabilirsiniz.(@furkan09)<br><br><br><br>
		Eğer zaten çeviri ekibindeyseniz giriş yapın:<br>
            <a href="girisyap.php">Giriş Yap</a>
            
        </div>
    </div>
</body>
</html>
