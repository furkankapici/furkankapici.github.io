<?php
session_start(); // Oturumu başlat

// Veritabanı bağlantısını içe aktarın
include('veritabani_baglanti.php');

// Kullanıcı oturumu kontrol et
if (!isset($_SESSION['user_id'])) {
    // Oturum açmamış kullanıcıyı giriş yapma sayfasına yönlendir
    echo "Önce oturum açın.";
    exit(); // Yönlendirme sonrası kodun çalışmasını durdur
}

// Kullanıcı kimliğini (user_id) alın
$user_id = $_SESSION['user_id'];

// POST verilerini alın
if (isset($_POST['mesaj_id']) && isset($_POST['duzenlenmis_mesaj'])) {
    $mesaj_id = $_POST['mesaj_id'];
    $duzenlenmis_mesaj = $_POST['duzenlenmis_mesaj'];

    // Mesajın göndereni oturum açan kullanıcı mı diye kontrol edin
    $sql = "SELECT kullanici_id FROM mesajlar WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $mesaj_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();

    if ($row['kullanici_id'] == $user_id) {
        // Mesajın sahibi ise mesajı güncelle
        $sql = "UPDATE mesajlar SET mesaj_metni = ? WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("si", $duzenlenmis_mesaj, $mesaj_id);
        $stmt->execute();
        $stmt->close();
    } else {
        echo "Bu mesajı düzenleme izniniz yok.";
    }
} else {
    echo "Geçersiz istek.";
}

// Veritabanı bağlantısını kapatın
$conn->close();
?>
