<?php
include('veritabani_baglanti.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $hashed_password = password_hash($password, PASSWORD_DEFAULT); // Parolayı güvenli bir şekilde sakla

    if (strlen($username) > 20) {
        echo "Kullanıcı adı 20 karakterden uzun olamaz.";
    } else {
        // Kullanıcıyı veritabanına ekle
        $sql = "INSERT INTO kullanicilar (kullaniciadi, sifre) VALUES (?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ss", $username, $hashed_password);

        if ($stmt->execute()) {
            $user_id = $stmt->insert_id; // Yeni kullanıcının ID'sini al
            echo "Kayıt başarıyla tamamlandı. Kullanıcı ID: " . $user_id;
        } else {
            echo "Hata: " . $stmt->error;
        }

        $stmt->close();
    }
}

$conn->close();
?>
