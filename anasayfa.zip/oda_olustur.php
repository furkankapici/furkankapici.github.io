<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Oda Oluştur</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }

        .content {
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
            width: 300px;
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        label {
            font-weight: bold;
            margin-bottom: 5px;
        }

        input[type="text"] {
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 3px;
        }

        input[type="submit"] {
            background-color: #007bff;
            color: #fff;
            padding: 10px;
            border: none;
            border-radius: 3px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <?php include('yanmenu.php'); ?>

    <div class="content">
        <h2>Oda Oluştur</h2>
        <form action="oda_ekle.php" method="POST">
            <label for="room_name">Oda Adı:</label>
            <input type="text" id="room_name" name="room_name" required>

            <label for="gizlilik">Gizlilik:</label>
            <select id="gizlilik" name="gizlilik">
                <option value="0">Halka Açık</option>
                <option value="1">Gizli</option>
            </select>

            <input type="submit" value="Oda Oluştur">
        </form>
    </div>
</body>
</html>
