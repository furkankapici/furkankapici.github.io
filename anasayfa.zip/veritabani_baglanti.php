<?php
$servername = "localhost"; // MySQL sunucusu
$username = "root"; // MySQL kullanıcı adı
$password = ""; // MySQL parolası
$dbname = "furkansohbet"; // Veritabanı adı

// MySQL bağlantısını oluştur
$conn = new mysqli($servername, $username, $password, $dbname);

// Bağlantıyı kontrol et
if ($conn->connect_error) {
    die("Bağlantı hatası: " . $conn->connect_error);
}
?>
