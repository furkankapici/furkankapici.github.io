<?php
session_start(); // Oturumu başlat

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $room_name = $_POST['room_name'];
    $gizlilik = $_POST['gizlilik']; // Gizlilik değerini al
    $uye_kullanici_id = $_SESSION['user_id']; // Oturum bilgilerinden kullanıcı adını al

    // Veritabanına odayı ekle
    include('veritabani_baglanti.php'); // Veritabanı bağlantısı

    $sql = "INSERT INTO odalar (oda_adi, gizlilik) VALUES (?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("si", $room_name, $gizlilik);

    if ($stmt->execute()) {
        // Oda oluşturuldu, şimdi oluşturan kullanıcıyı odaya ekleyin
        $oda_id = $stmt->insert_id; // Yeni eklenen oda ID'sini al

        // Eğer oda halka açık değilse, odaya katılımı "oda_uyeleri" tablosuna ekle
        if ($gizlilik != 0) {
            $sql_katilim = "INSERT INTO oda_uyeleri (uye_kullanici, oda_id) VALUES (?, ?)";
            $stmt_katilim = $conn->prepare($sql_katilim);
            $stmt_katilim->bind_param("si", $uye_kullanici_id, $oda_id);

            if ($stmt_katilim->execute()) {
                echo "Oda başarıyla oluşturuldu ve siz de katıldınız.";
            } else {
                echo "Oda oluşturuldu, ancak katılım sırasında bir hata oluştu: " . $stmt_katilim->error;
            }

            $stmt_katilim->close();
        } else {
            echo "Oda başarıyla oluşturuldu.";
        }
    } else {
        echo "Hata: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>
