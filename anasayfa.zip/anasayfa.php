<?php
session_start(); // Oturumu başlat

// Oturum kontrolü yap
if (!isset($_SESSION['username'])) {
    header("location: girisyap.php"); // Kullanıcı giriş yapmamışsa giriş sayfasına yönlendir
    exit(); // Kodun devamını çalıştırma
}

?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hoş Geldiniz, <?php echo $_SESSION['username']; ?></title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }

        .container {
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
            width: 300px;
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        p {
            text-align: center;
            font-size: 18px;
            margin-bottom: 20px;
        }

        a {
            display: block;
            text-align: center;
            text-decoration: none;
            background-color: #007bff;
            color: #fff;
            padding: 10px;
            border-radius: 3px;
        }

        a:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
<?php include('yanmenu.php'); ?>
    <div class="container">
        <h2>Hoş Geldiniz, <?php echo $_SESSION['username']; ?>!</h2>
        <p>Bu sizin özel anasayfanızdır.</p>
        <a href="cikis.php">Çıkış Yap</a>
    </div>
</body>
</html>
