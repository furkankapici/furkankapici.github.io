<?php
session_start(); // Oturumu başlat

// Kullanıcı oturumu kontrol et
if (!isset($_SESSION['user_id'])) {
    // Oturum açmamış kullanıcıyı giriş yapma sayfasına yönlendir
    header("Location: girisyap.php");
    exit(); // Yönlendirme sonrası kodun çalışmasını durdur
}

// Oturum açmış kullanıcı işlemleri burada devam edebilir
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Oda Mesajları</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
    <div id="mesajlar"></div>

    <form id="mesajGonderForm" style="display: block;">
        <input type="text" id="mesajMetni" placeholder="Mesajınızı yazın" required>
        <input type="submit" value="Gönder">
    </form>
	
<div style="display: none;" id='mesaj_duzenle_form'>
    <form>
        <input id="mesaj_duzenle_girdi" type='hidden' name='mesaj_id' value='31'>
        <textarea id="mesaj_duzenle" name='duzenlenmis_mesaj'></textarea>
        <button type='button' onclick="duzenlenenMesajiKaydet()">Kaydet</button>
    </form>
    <button onclick="mesajDuzenleVazgeç()">Vazgeç</button>
</div>
	 
    <script>
$(document).ready(function() {
    // Sayfa yüklendiğinde ve belirli aralıklarla oda mesajlarını görüntüle
    function getOdaMesajlari() {
        var oda_id = <?php echo $_GET['oda_id']; ?>; // Oda kimliğini PHP'den alın

        $.ajax({
            type: 'GET',
            url: 'mesajlari_al.php',
            data: { oda_id: oda_id },
            success: function(response) {
                $('#mesajlar').html(response);
            }
        });
    }

    // Mesaj gönderme formunu işle
    $('#mesajGonderForm').submit(function(e) {
        e.preventDefault(); // Formun varsayılan davranışını engelle
        var mesajMetni = $('#mesajMetni').val(); // Mesaj metnini al

         // Mesajı gönder ve ekrana ekleyin
        $.ajax({
            type: 'POST',
            url: 'mesaj_gonder.php',
            data: { oda_id: <?php echo $_GET['oda_id']; ?>, mesaj_metni: mesajMetni },
            success: function(response) {
            $('#mesajMetni').val(''); // Mesaj kutusunu temizle
            getOdaMesajlari(); // Mesajları yeniden yükle
        }
		});
    });

    // Sayfa yüklendiğinde ve belirli aralıklarla mesajları güncelle
    getOdaMesajlari();
    setInterval(getOdaMesajlari, 0500); // Örneğin, her 500 milisaniyede bir güncelle
    });


function duzenleMesaj(mesajId) {
  var mesajDuzenlemeForm = document.getElementById('mesaj_duzenle_form');
  var mesajYazmaForm = document.getElementById('mesajGonderForm');
  // Kaynak metin kutusunun değerini al
  var kaynakMetin = document.getElementById("mesaj_" + mesajId).innerHTML;
  // Hedef metin kutusuna kopyala
  document.getElementById("mesaj_duzenle").value = kaynakMetin;

  var mesajIdInput = document.querySelector("input[name='mesaj_id']");
  mesajIdInput.value = mesajId;
  
  // Mesaj düzenleme formunu göster
  mesajDuzenlemeForm.style.display = 'block';
  mesajYazmaForm.style.display = 'none';
}

function duzenlenenMesajiKaydet() {
    var mesajId = document.querySelector('input[name="mesaj_id"]').value;
    var duzenlenmisMesaj = document.querySelector('textarea[name="duzenlenmis_mesaj"]').value;
    
    var xhr = new XMLHttpRequest();
    xhr.open('POST', 'mesaj_duzenle.php', true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    
    xhr.onreadystatechange = function() {
        if (xhr.readyState === 4 && xhr.status === 200) {
            // Sunucudan gelen yanıtı işleyin (örneğin, kullanıcıya bir bildirim gösterin veya sayfa içeriğini güncelleyin).
        }
    };
    
    var data = 'mesaj_id=' + mesajId + '&duzenlenmis_mesaj=' + duzenlenmisMesaj;
    xhr.send(data);
	
	var mesajDuzenlemeForm = document.getElementById('mesaj_duzenle_form');
	var mesajYazmaForm = document.getElementById('mesajGonderForm');
	mesajDuzenlemeForm.style.display = 'none';
	mesajYazmaForm.style.display = 'block';
	document.getElementById("mesaj_duzenle").value = "";
}

function mesajDuzenleVazgeç(){
  var mesajDuzenlemeForm = document.getElementById('mesaj_duzenle_form');
  var mesajYazmaForm = document.getElementById('mesajGonderForm');
  mesajDuzenlemeForm.style.display = 'none';
  mesajYazmaForm.style.display = 'block';
  document.getElementById("mesaj_duzenle").value = "";
}
</script>
</body>
</html>
