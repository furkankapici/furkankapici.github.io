<?php
session_start(); // Oturumu başlat

// Veritabanı bağlantısını içe aktarın
include('veritabani_baglanti.php');

// Kullanıcı oturumu kontrol et
if (!isset($_SESSION['user_id'])) {
    // Oturum açmamış kullanıcıyı giriş yapma sayfasına yönlendir
    echo "Önce oturum açın.";
    exit(); // Yönlendirme sonrası kodun çalışmasını durdur
}

// Kullanıcı kimliğini (user_id) alın
$user_id = $_SESSION['user_id'];

// Fonksiyon ile kullanıcı adını çekmek
function getUserName($conn, $user_id) {
    $sql = "SELECT kullaniciadi FROM kullanicilar WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    return $row['kullaniciadi'];
}

// Kullanıcının adını alın
$kullaniciadi = getUserName($conn, $user_id);

// Oda kimliğini (oda_id) URL'den alın
if (isset($_GET['oda_id'])) {
    $oda_id = $_GET['oda_id'];

    // Odaya ait mesajları ve kullanıcıya ait mesajları sorgulayın (örnek sıralama: en yeni en üstte)
    $sql = "SELECT m.id, m.mesaj_metni, m.kullanici_id, m.tarih
            FROM mesajlar m
            WHERE (m.oda = ?)
            ORDER BY m.tarih ASC";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $oda_id);
    $stmt->execute();
    $result = $stmt->get_result();

    // Mesajları ekrana yazdırın
    while ($row = $result->fetch_assoc()) {
        $mesaj = $row['mesaj_metni'];
        $gonderen = $row['kullanici_id'];
        $tarih = $row['tarih'];
        $mesaj_id = $row['id'];

        // Mesajın göndereni oturum açan kullanıcıysa, düzenle butonu ekleyin
        if ($gonderen == $user_id) {
            echo "<div><strong>$kullaniciadi</strong> - $tarih - <button onclick='duzenleMesaj($mesaj_id)'>Düzenle</button></div>";
            echo "<div id='mesaj_$mesaj_id'>$mesaj</div>";

            // Düzenleme formunu ekleyin
            //echo "<div id='duzenle_form_$mesaj_id' style='display:none;'>";
            //echo "<form method='POST' action='mesaj_duzenle.php'>";
            //echo "<input type='hidden' name='mesaj_id' value='$mesaj_id'>";
            //echo "<textarea name='duzenlenmis_mesaj'>$mesaj</textarea>";
            //echo "<button type='submit'>Kaydet</button>";
            //echo "</form>";
            //echo "</div>";
        } else {
            // Mesajı gönderenin adını alın
            $gonderen_adi = getUserName($conn, $gonderen);

            echo "<div><strong>$gonderen_adi</strong> - $tarih</div>";
            echo "<div id='mesaj_$mesaj_id'>$mesaj</div>";
        }
    }

    $stmt->close();
} else {
    echo "Oda kimliği (oda_id) belirtilmedi.";
}


// Veritabanı bağlantısını kapatın
$conn->close();
?>
