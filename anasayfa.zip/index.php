<!DOCTYPE html>
<html>
<head>
<title>Hoşgeldin</title>
</head>
<body>
<h1>BETA MENÜSÜ</h1>
<a href="girisyap.php">giriş yap</a><br>
<a href="kayitol.php">kaydol</a>
<h3>Bu yeni çıkartacağım mesaj uygulamasının beta menüsüdür henüz mesaj atma mevcut değildir denemek için seçenekler yukarıda mevcut</h3>
<small>Beta sürümler karasız çalışabilir</small><br><br><br>
Oluşan hataları bana bildirin:<br>
Discord: @furkan09 / furkan09#0001<br>
</body>
</html>
