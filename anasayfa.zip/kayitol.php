<?php
session_start(); // Oturumu başlat

// Eğer kullanıcı zaten oturum açtıysa, anasayfaya yönlendir
if (isset($_SESSION['user_id'])) {
    header("Location: anasayfa.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kayıt Ol</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }

        .container {
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
            width: 300px;
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        label {
            font-weight: bold;
            margin-bottom: 5px;
        }

        input[type="text"],
        input[type="password"],
        input[type="file"] {
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 3px;
        }

        input[type="submit"] {
            background-color: #007bff;
            color: #fff;
            padding: 10px;
            border: none;
            border-radius: 3px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Kayıt Ol</h2>
        <form action="kullanicikayit.php" method="POST" enctype="multipart/form-data">
            <label for="username">Kullanıcı Adı:</label>
            <input type="text" id="username" name="username" required maxlength="20" required>

            <label for="password">Şifre:</label>
            <input type="password" id="password" name="password" required>

            <label for="profile_picture">Profil Fotoğrafı:</label>
            <input type="file" id="profile_picture" name="profile_picture">
            <small>Varsayılan profil fotoğrafı eklemek için bu alanı boş bırakabilirsiniz.</small>

            <input type="submit" value="Kayıt Ol">
        </form>
    </div>
</body>
</html>
