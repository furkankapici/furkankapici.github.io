<?php
session_start(); // Oturumu başlat

// Oturumu sonlandır
if (isset($_SESSION['username'])) {
    session_destroy(); // Oturumu sonlandır
}

// Kullanıcıyı giriş sayfasına yönlendir
header("location: girisyap.php");
exit();
?>
